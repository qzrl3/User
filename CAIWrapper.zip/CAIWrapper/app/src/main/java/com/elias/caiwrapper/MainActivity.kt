package com.elias.caiwrapper

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import java.io.File

/**
 * Loads character.ai in a WebView and injects a userscript.
 *
 * The script is NOT baked into the APK permanently — on first launch it's copied
 * from assets/userscript.js into the app's external files dir
 * (Android/data/com.elias.caiwrapper/files/userscript.js). After that, this
 * external copy is what actually gets loaded and it wins over the bundled
 * version. To change the script without rebuilding:
 *
 *   adb push my_updated_script.js /storage/emulated/0/Android/data/com.elias.caiwrapper/files/userscript.js
 *
 * or, from Termux with storage permission granted:
 *
 *   cp my_updated_script.js /sdcard/Android/data/com.elias.caiwrapper/files/userscript.js
 *
 * Then just relaunch the app (no recompile needed).
 */
class MainActivity : AppCompatActivity() {

    private val startUrl = "https://character.ai/"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val webView = findViewById<WebView>(R.id.webview)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            javaScriptCanOpenWindowsAutomatically = true
            setSupportMultipleWindows(false)
            userAgentString = userAgentString.replace("; wv", "")
        }
        webView.webViewClient = WebViewClient()

        val script = loadUserScript()

        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            // True document-start injection: runs before ANY page JS, including
            // inline scripts in <head> and the main.js bundle. This is what the
            // script's redirect-kill logic needs.
            WebViewCompat.addDocumentStartJavaScript(
                webView,
                script,
                setOf("https://*.character.ai/*", "https://character.ai/*")
            )
        } else {
            // Fallback for old WebView builds: fires as early as the platform
            // allows, but page JS may already be running by then.
            webView.webViewClient = object : WebViewClient() {
                override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                    view.evaluateJavascript(script, null)
                }
            }
        }

        if (savedInstanceState == null) {
            webView.loadUrl(startUrl)
        }
    }

    /**
     * Reads the userscript from external storage if present (so it can be swapped
     * without rebuilding the app), otherwise falls back to the copy bundled in
     * assets/ and seeds the external copy for next time.
     */
    private fun loadUserScript(): String {
        val externalFile = File(getExternalFilesDir(null), "userscript.js")
        if (externalFile.exists()) {
            return externalFile.readText()
        }
        val bundled = assets.open("userscript.js").bufferedReader().use { it.readText() }
        runCatching {
            externalFile.parentFile?.mkdirs()
            externalFile.writeText(bundled)
        }
        return bundled
    }
}
